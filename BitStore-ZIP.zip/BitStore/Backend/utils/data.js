const items = [
    {
        name: 'Samosa (2pcs)',
        price: 20,
        category: 'Appetizers',
        image: "https://imgur.com/a/2yIrjfy",
        productid: 101,
    },
    {
        name: 'Pakoras (2pcs)',
        price: 20,
        category: 'Appetizers',
        image: "https://imgur.com/a/QrpG6g9",
        productid: 102,
    },
    {
        name: 'Dahi Chaat',
        price: 50,
        category: 'Appetizers',
        image: "https://imgur.com/a/jWEEFNF",
        productid: 103,
    },
    {
        name: 'Tea',
        price: 10,
        category: 'Beverages',
        image: "https://imgur.com/a/EF8pYVc",
        productid: 104,
    },
    {
        name: 'Coffe',
        price: 15,
        category: 'Beverages',
        image: "https://imgur.com/a/Md9mzMc",
        productid: 105,
    },
    {
        name: 'Lassi',
        price: 40,
        category: 'Beverages',
        image: "https://imgur.com/a/80OnNn7",
        productid: 106,
    },
    {
        name: 'Chaas',
        price: 20,
        category: 'Beverages',
        image: "https://imgur.com/a/x2ktIlE",
        productid: 107,
    },
    {
        name: 'Gulab Jamun (2 Pcs)',
        price: 20,
        category: 'Desserts',
        image: "https://imgur.com/a/0eOjGUx",
        productid: 108,
    },
    {
        name: 'Kulfi',
        price: 10,
        category: 'Desserts',
        image: "https://imgur.com/a/DlXLigC",
        productid: 109,
    },
    {
        name: 'Kheer',
        price: 50,
        category: 'Desserts',
        image: "https://imgur.com/a/p3Oi8nu",
        productid: 110,
    },

];
module.exports = items;